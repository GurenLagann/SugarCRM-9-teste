<?php

$mod_strings['LBL_JOB_AVISO_SEMANA'] = 'JOB Aviso de uma semana';
