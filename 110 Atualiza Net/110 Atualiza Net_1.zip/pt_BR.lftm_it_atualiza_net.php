<?php


$mod_strings['LBL_LFTM_IT_ATUALIZA_NET'] = 'JOB Atualiza Net e Perfil';