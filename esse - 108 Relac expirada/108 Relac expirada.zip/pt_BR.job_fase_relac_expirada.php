<?php

$mod_strings['LBL_JOB_FASE_RELAC_EXPIRADA'] = 'JOB Relacionamento Expirado';
