<?php

$mod_strings['LBL_JOB_CANCELA_CHAMADA'] = 'JOB Cancela Chamada';
