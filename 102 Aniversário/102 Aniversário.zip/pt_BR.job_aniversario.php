<?php

$mod_strings['LBL_JOB_ANIVERSARIO'] = 'JOB ANIVERSARIO';
