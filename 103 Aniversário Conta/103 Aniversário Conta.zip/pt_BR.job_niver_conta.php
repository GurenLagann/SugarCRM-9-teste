<?php

$mod_strings['LBL_JOB_NIVER_CONTA'] = 'JOB NIVER CONTA';
