<?php

$mod_strings['LBL_JOB_CANCELA_REUNIAO'] = 'JOB Cancela Reuniao';
