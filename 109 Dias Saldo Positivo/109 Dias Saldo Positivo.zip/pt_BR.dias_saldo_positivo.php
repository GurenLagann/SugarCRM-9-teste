<?php

$mod_strings['LBL_DIAS_SALDO_POSITIVO'] = 'JOB Dias Saldo Positivo';