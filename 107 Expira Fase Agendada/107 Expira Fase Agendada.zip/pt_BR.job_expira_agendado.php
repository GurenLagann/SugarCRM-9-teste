<?php

$mod_strings['LBL_JOB_EXPIRA_AGENDADO'] = 'JOB Expira Agendado';
