<?php


$mod_strings['LBL_LFTM_IT_TASK_AUDIT_JOB'] = 'Verifica atraso de tarefas para auditoria';
