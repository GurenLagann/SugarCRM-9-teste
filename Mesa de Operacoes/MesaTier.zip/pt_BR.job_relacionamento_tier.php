<?php

$mod_strings['LBL_JOB_RELACIONAMENTO_TIER'] = 'JOB Analisa relacionamento tier';
